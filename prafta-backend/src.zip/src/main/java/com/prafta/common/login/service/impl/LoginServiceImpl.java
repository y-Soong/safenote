package com.prafta.common.login.service.impl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.prafta.common.login.dto.LoginReqDto;
import com.prafta.common.login.mapper.LoginMapper;
import com.prafta.common.login.service.LoginService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LoginServiceImpl implements LoginService{
	private final LoginMapper loginMapper;
	
	public LoginServiceImpl(LoginMapper loginMapper) {
		this.loginMapper = loginMapper;
	}
	
	public Map<String, Object> getLoginUser(LoginReqDto dto) {
		
		log.info("getLoginUser #####");
		
		return loginMapper.getLoginUser(dto);
	}
}
