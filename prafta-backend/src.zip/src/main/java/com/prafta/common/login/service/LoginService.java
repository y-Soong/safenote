package com.prafta.common.login.service;

import java.util.Map;

import com.prafta.common.login.dto.LoginReqDto;

public interface LoginService {
	Map<String, Object> getLoginUser(LoginReqDto dto); 
}
