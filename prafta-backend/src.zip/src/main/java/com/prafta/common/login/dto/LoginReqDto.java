package com.prafta.common.login.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginReqDto {
	private String userId;
    private String userNm;
    private String userPw;
}
