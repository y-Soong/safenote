package com.prafta.common.config;

import java.lang.reflect.Method;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.boot.autoconfigure.web.servlet.WebMvcRegistrations;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
import org.springframework.web.util.pattern.PathPatternParser;

@Configuration
public class ApiPrefixConfig implements WebMvcRegistrations {

	 @Bean
	    @Primary
	    public RequestMappingHandlerMapping customRequestMappingHandlerMapping() { // 이름 변경 🔥
		 	System.out.println("RequestMappingHandlerMapping ####");
		 
	        ApiPrefixHandlerMapping mapping = new ApiPrefixHandlerMapping();
	        mapping.setPatternParser(new PathPatternParser()); // Spring 2.6+ 필요
	        return mapping;
	    }

    static class ApiPrefixHandlerMapping extends RequestMappingHandlerMapping {

        private static final String WEB_PACKAGE = "com.prafta.web";
        private static final String APP_PACKAGE = "com.prafta.app";
        private static final String COM_PACKAGE = "com.prafta.common";

        private static final String WEB_API_PREFIX = "/webApi";
        private static final String APP_API_PREFIX = "/appApi";
        private static final String COM_API_PREFIX = "/comApi";

        @Override
        protected void registerHandlerMethod(Object handler, Method method, RequestMappingInfo mapping) {
        	System.out.println("registerHandlerMethod ###");
        	
            Class<?> beanType = method.getDeclaringClass();
            String packageName = beanType.getPackageName();

            String prefix = null;
            if (packageName.startsWith(WEB_PACKAGE)) {
                prefix = WEB_API_PREFIX;
            } else if (packageName.startsWith(APP_PACKAGE)) {
                prefix = APP_API_PREFIX;
            } else if (packageName.startsWith(COM_PACKAGE)) {
                prefix = COM_API_PREFIX;
            }

            if (prefix != null && mapping != null && mapping.getPatternsCondition() != null) {
                Set<String> originalPatterns = mapping.getPatternsCondition().getPatterns();
                if (originalPatterns == null || originalPatterns.isEmpty()) {
                    super.registerHandlerMethod(handler, method, mapping);
                    return;
                }

                final String finalPrefix = prefix;
                Set<String> updatedPatterns = originalPatterns.stream()
                        .map(url -> finalPrefix + url)
                        .collect(Collectors.toSet());

                System.out.println("✅ 등록된 URL: " + updatedPatterns);

                PatternsRequestCondition updatedPatternCondition =
                        new PatternsRequestCondition(updatedPatterns.toArray(new String[0]));

                mapping = new RequestMappingInfo(
                        mapping.getName(),
                        updatedPatternCondition,
                        mapping.getMethodsCondition(),
                        mapping.getParamsCondition(),
                        mapping.getHeadersCondition(),
                        mapping.getConsumesCondition(),
                        mapping.getProducesCondition(),
                        mapping.getCustomCondition()
                );
            }

            super.registerHandlerMethod(handler, method, mapping);
        }
    }
}

