package com.prafta.common.security;

import java.security.Key;
import java.util.Date;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {

    private final String secret = "cleannote-cleaning-platform-jwt-secret-key-2025";
    private final long expiration = 1000 * 60 * 60 * 2; // 2�ð�

    private final Key key = Keys.hmacShaKeyFor(secret.getBytes());

    public String generateToken(String userId, String userNm, String cmpnyCd) {
        return Jwts.builder()
                .claim("userId", userId)
                .claim("userNm", userNm)
                .claim("cmpnyCd", cmpnyCd)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }

    public Claims parseToken(String token) throws JwtException {
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    public boolean validateToken(String token) {
        try {
            Claims claims = parseToken(token);
            return !claims.getExpiration().before(new Date());
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
    }

    public String getUserIdFromToken(String token) {
        return parseToken(token).get("userId", String.class);
    }

    public String getUserNameFromToken(String token) {
        return parseToken(token).get("userNm", String.class);
    }

    public String getCompanyCodeFromToken(String token) {
        return parseToken(token).get("cmpnyCd", String.class);
    }
}
