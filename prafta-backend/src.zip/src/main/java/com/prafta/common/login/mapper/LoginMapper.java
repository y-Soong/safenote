package com.prafta.common.login.mapper;

import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.prafta.common.login.dto.LoginReqDto;

@Mapper
public interface LoginMapper {
	Map<String, Object> getLoginUser(LoginReqDto dto);
}
