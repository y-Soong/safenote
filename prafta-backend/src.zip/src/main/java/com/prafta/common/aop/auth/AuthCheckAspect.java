package com.prafta.common.aop.auth;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.prafta.common.exception.LoginFailException;
import com.prafta.common.security.JwtUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class AuthCheckAspect {

    private final JwtUtil jwtUtil;

    // @AuthCheck ������̼��� ���� �޼��带 ������� ����
    @Pointcut("@annotation(com.prafta.common.aop.auth.AuthCheck)")
    public void authCheckTarget() {}

    @Before("authCheckTarget()")
    public void validateToken() {
        HttpServletRequest request =
            ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();

        String authHeader = request.getHeader("Authorization");

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new LoginFailException("���� ��ū�� �����ϴ�.");
        }

        String token = authHeader.substring(7); // "Bearer " ���� ��ū

        if (!jwtUtil.validateToken(token)) {
            throw new LoginFailException("��ȿ���� ���� ��ū�Դϴ�.");
        }

        log.info("���� ����: {}", jwtUtil.getUserIdFromToken(token));
    }
}
