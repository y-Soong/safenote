package com.prafta.common.aop.auth;

import java.nio.charset.StandardCharsets;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.prafta.common.exception.UnauthorizedException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import lombok.RequiredArgsConstructor;

@Aspect
@Component
@RequiredArgsConstructor
public class AuthAspect {

    private final HttpServletRequest request;
    private static final String SECRET_KEY = "yourSecretKey";

    @Before("execution(* com.example.project.controller..*(..)) && !@annotation(com.prafta.common.annotation.NoAuth)")
    public void checkAuthorization(JoinPoint joinPoint) {
        String token = request.getHeader("Authorization");

        if (token == null || !token.startsWith("Bearer ")) {
            throw new UnauthorizedException("��ū�� �����ϴ�.");
        }

        try {
            Claims claims = Jwts.parser()
                .setSigningKey(SECRET_KEY.getBytes(StandardCharsets.UTF_8))
                .parseClaimsJws(token.substring(7))
                .getBody();
            // claims.getSubject() �� �ʿ� �� Ȱ��
        } catch (Exception e) {
            throw new UnauthorizedException("��ȿ���� ���� ��ū�Դϴ�.");
        }
    }
}