package com.prafta.common.login.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prafta.common.annotation.NoAuth;
import com.prafta.common.exception.LoginFailException;
import com.prafta.common.login.dto.LoginReqDto;
import com.prafta.common.login.service.LoginService;
import com.prafta.common.security.JwtUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@NoAuth
@RequestMapping("/login")
@RequiredArgsConstructor // �Һ��� final �ʵ�� ������ �ڵ� ����
public class LoginController { 	
	
	private final JwtUtil jwtUtil;
	private final LoginService loginService;

//    public LoginController(JwtUtil jwtUtil) {
//        this.jwtUtil = jwtUtil;
//    }

    @PostMapping("/loginChk")
    public ResponseEntity<?> Login(@RequestBody LoginReqDto dto) {
    	log.info("Login ###");
    	log.info("userId :: " + dto.getUserId());
		log.info("userPW :: " + dto.getUserPw());
		
		Map<String, Object> retMap = loginService.getLoginUser(dto);
		
		log.info("retMap :: " + retMap);
    	
    	if(retMap != null) {
    		
    		String token = jwtUtil.generateToken(retMap.get("USER_ID").toString(), retMap.get("USER_NM").toString(), retMap.get("CMPNY_CD").toString());		// ��ū ����
    		
    		retMap.put("retMsg", "�α��ο� �����߽��ϴ�.");
    		
    		retMap.put("userId", retMap.get("USER_ID"));
    		retMap.put("userNm", retMap.get("USER_NM"));
    		retMap.put("cmpnyCd", retMap.get("CMPNY_CD"));
    		retMap.put("token", token);
    	} else {
    		throw new LoginFailException("���̵� Ȥ�� ��й�ȣ�� Ȯ�����ּ���.");
    	}
    	
    	return ResponseEntity.status(HttpStatus.OK).body(retMap);
    }
}
